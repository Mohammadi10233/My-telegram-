
import telebot
from telebot import types

API_TOKEN = 'توکن-ربات-تو-اینجا-بذار'

bot = telebot.TeleBot(API_TOKEN)

boys_queue = []
girls_queue = []
random_queue = []
chats = {}

def find_partner(user_id, gender_list):
    for partner_id in gender_list:
        if partner_id != user_id and partner_id not in chats.values():
            return partner_id
    return None

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.send_message(message.chat.id, "سلام! خوش اومدی به ربات چت ناشناس 🤖\n"
                                      "برای شروع، /join بنویس و جنسیتت رو انتخاب کن.")

@bot.message_handler(commands=['join'])
def join_queue(message):
    markup = types.ReplyKeyboardMarkup(one_time_keyboard=True, resize_keyboard=True)
    markup.add('پسر', 'دختر', 'بی‌تفاوت')
    msg = bot.send_message(message.chat.id, "لطفا جنسیت خودت رو انتخاب کن:", reply_markup=markup)
    bot.register_next_step_handler(msg, process_gender_step)

def process_gender_step(message):
    gender = message.text
    user_id = message.chat.id
    if user_id in chats:
        bot.send_message(user_id, "تو همین الان در چتی هستی. برای خروج /leave رو بزن.")
        return

    if gender == 'پسر':
        boys_queue.append(user_id)
        bot.send_message(user_id, "شما به صف پسرها اضافه شدی. منتظر باش تا به کسی وصل بشی...")
    elif gender == 'دختر':
        girls_queue.append(user_id)
        bot.send_message(user_id, "شما به صف دخترها اضافه شدی. منتظر باش تا به کسی وصل بشی...")
    else:
        random_queue.append(user_id)
        bot.send_message(user_id, "شما به صف بی‌تفاوت‌ها اضافه شدی. منتظر باش تا به کسی وصل بشی...")

    try_to_match(user_id, gender)

def try_to_match(user_id, gender):
    partner_id = None
    if gender == 'پسر':
        partner_id = find_partner(user_id, girls_queue)
    elif gender == 'دختر':
        partner_id = find_partner(user_id, boys_queue)
    else:
        partner_id = find_partner(user_id, boys_queue)
        if not partner_id:
            partner_id = find_partner(user_id, girls_queue)

    if partner_id:
        chats[user_id] = partner_id
        chats[partner_id] = user_id

        if user_id in boys_queue:
            boys_queue.remove(user_id)
        if user_id in girls_queue:
            girls_queue.remove(user_id)
        if user_id in random_queue:
            random_queue.remove(user_id)

        if partner_id in boys_queue:
            boys_queue.remove(partner_id)
        if partner_id in girls_queue:
            girls_queue.remove(partner_id)
        if partner_id in random_queue:
            random_queue.remove(partner_id)

        bot.send_message(user_id, "شما به یک چت ناشناس وصل شدی. پیام بده...")
        bot.send_message(partner_id, "شما به یک چت ناشناس وصل شدی. پیام بده...")

def send_message_to_partner(message):
    user_id = message.chat.id
    if user_id in chats:
        partner_id = chats[user_id]
        try:
            bot.send_message(partner_id, message.text)
        except Exception:
            bot.send_message(user_id, "ارسال پیام به طرف مقابل امکان‌پذیر نیست.")
    else:
        bot.send_message(user_id, "شما در هیچ چتی نیستید. برای شروع /join بزنید.")

@bot.message_handler(commands=['leave'])
def leave_chat(message):
    user_id = message.chat.id
    if user_id in chats:
        partner_id = chats[user_id]
        bot.send_message(partner_id, "طرف مقابل چت را ترک کرد.")
        del chats[partner_id]
        del chats[user_id]
        bot.send_message(user_id, "شما از چت خارج شدید.")
    else:
        bot.send_message(user_id, "شما در هیچ چتی نیستید.")

@bot.message_handler(func=lambda message: True)
def handle_all_messages(message):
    send_message_to_partner(message)

bot.polling()
